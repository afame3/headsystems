<?php
/**
* @copyright (C) 2013 iJoomla, Inc. - All rights reserved.
* @license GNU General Public License, version 2 (http://www.gnu.org/licenses/gpl-2.0.html)
* @author iJoomla.com <webmaster@ijoomla.com>
* @url https://www.jomsocial.com/license-agreement
* The PHP code portions are distributed under the GPL license. If not otherwise stated, all images, manuals, cascading style sheets, and included JavaScript *are NOT GPL, and are released under the IJOOMLA Proprietary Use License v1.0
* More info at https://www.jomsocial.com/license-agreement
*/
// Disallow direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">
Joomla.submitbutton = function(action){
	submitbutton( action );
}
</script>

<!-- <div id="submenu-box">
	<div class="t"><div class="t"><div class="t"></div></div></div>
	<div class="m">
		<ul id="submenu" class="jsconfiguration">
			<li><a href="#" onclick="return false;" id="main" class="active"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_SITE_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="media"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_MEDIA_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="antispam"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_ANTISPAM_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="groups"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_GROUPS_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="events"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_EVENTS_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="layout"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_LAYOUT_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="privacy"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_PRIVACY_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="facebook-connect"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_FACEBOOK_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="remote-storage"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_REMOTE_TOOLBAR' ); ?></a></li>
			<li><a href="#" onclick="return false;" id="integrations"><?php echo JText::_( 'COM_COMMUNITY_CONFIGURATION_INTEGRATIONS_TOOLBAR' ); ?></a></li>
		</ul>
		<div class="clr"></div>
	</div>
	<div class="b"><div class="b"><div class="b"></div></div></div>
</div> -->
<div class="clr"></div>
